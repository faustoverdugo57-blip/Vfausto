package com.fausto.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener as VoskListener
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.Random
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class FaustoService : Service(), Tools {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var brain: Brain
    private lateinit var cloud: CloudVoice
    private var player: MediaPlayer? = null

    private var orb: OrbView? = null
    private var orbLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var logView: TextView? = null
    private var scroll: ScrollView? = null
    private var edit: EditText? = null
    private val logBuf = StringBuilder()

    private var voskModel: Model? = null
    private var voskRec: Recognizer? = null
    private var voskService: SpeechService? = null
    private var wakeGen = 0
    private var wakeOn = false
    private var wakeFailed = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var uttId = 0
    private var pulsing = false
    private val rnd = Random()

    @Volatile private var runId = 0
    @Volatile private var lastScale = 1f
    @Volatile private var busy = false

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = handler.post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("fausto", MODE_PRIVATE)
        brain = Brain(this, this)
        cloud = CloudVoice(this)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setPitch(0.8f)
                tts?.setSpeechRate(0.95f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { handler.post { if (id == "u$uttId") startPulse() } }
                    override fun onDone(id: String?) { handler.post { if (id == "u$uttId") finish() } }
                    override fun onError(id: String?) { handler.post { if (id == "u$uttId") finish() } }
                })
                ttsReady = true
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startForegroundNow()
        if (intent?.action == "SUMMON") {
            onWake()
        } else {
            restartWake()
            if (always()) showOrb()
        }
        return START_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fausto", "Fausto", NotificationManager.IMPORTANCE_LOW))
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, FaustoService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val icon = Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now)
        val n = Notification.Builder(this, "fausto")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Fausto hazır")
            .setContentText(if (wakeReady()) "'Hey Fausto' de" else "Çağırmak için aşağıdaki düğmeye bas")
            .addAction(Notification.Action.Builder(icon, "Çağır", pi("SUMMON", 1)).build())
            .addAction(Notification.Action.Builder(icon, "Kapat", pi("STOP", 2)).build())
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onDestroy() {
        runId++
        handler.removeCallbacksAndMessages(null)
        stopWake()
        try { voskModel?.close() } catch (e: Throwable) {}
        voskModel = null
        try { recognizer?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        try { player?.release() } catch (e: Exception) {}
        hideOrb()
        super.onDestroy()
    }

    // ---------- Uyandırma (Vosk, çevrimdışı; hesap/anahtar gerektirmez) ----------
    private fun voskDir() = File(filesDir, "vosk-model")
    private fun wakeEnabled() = prefs.getBoolean("wake_on", false)
    private fun wakeReady() = wakeEnabled() && File(voskDir(), ".ok").exists() &&
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun always() = prefs.getBoolean("always", false) || !wakeReady() || wakeFailed

    private fun norm(s: String): String = s.lowercase(Locale.forLanguageTag("tr-TR"))
        .replace('ı', 'i').replace('ğ', 'g').replace('ş', 's')
        .replace('ö', 'o').replace('ü', 'u').replace('ç', 'c')

    private fun wakeWords(): List<String> =
        prefs.getString("wake_words", "").orEmpty().ifBlank { "fausto,faust,fosto,avusto,agustos" }
            .split(",").map { norm(it.trim()) }.filter { it.length >= 3 }

    private fun heardWake(text: String): Boolean {
        val n = norm(text)
        return wakeWords().any { n.contains(it) }
    }

    private fun restartWake() {
        stopWake()
        wakeFailed = false
        startWake()
    }

    private fun startWake() {
        if (wakeOn || wakeFailed || !wakeReady()) return
        wakeOn = true
        val gen = ++wakeGen
        val m = voskModel
        if (m != null) { beginVosk(m); return }
        Thread {
            try {
                val model = Model(voskDir().absolutePath)
                handler.post {
                    if (voskModel != null) { try { model.close() } catch (e: Throwable) {} } else voskModel = model
                    if (wakeOn && gen == wakeGen) voskModel?.let { beginVosk(it) }
                }
            } catch (e: Throwable) {
                handler.post { if (gen == wakeGen) wakeFail("Vosk modeli yüklenemedi: ${e.message}") }
            }
        }.start()
    }

    private fun beginVosk(model: Model) {
        try {
            val rec = Recognizer(model, 16000.0f)
            voskRec = rec
            val svc = SpeechService(rec, 16000.0f)
            voskService = svc
            svc.startListening(voskListener)
        } catch (e: Throwable) {
            wakeFail("Uyandırma başlamadı: ${e.message}")
        }
    }

    private fun wakeFail(msg: String) {
        stopWake()
        wakeFailed = true
        appendLog(msg)
        showOrb()
    }

    private fun voskCheck(json: String?, key: String, isFinal: Boolean) {
        if (!wakeOn || json == null) return
        val t = try { JSONObject(json).optString(key) } catch (e: Exception) { "" }
        if (t.isBlank()) return
        val hit = heardWake(t)
        if (hit || isFinal) prefs.edit().putString("last_heard", t).apply()
        if (hit) {
            stopWake()
            handler.postDelayed({ onWake() }, 250)
        }
    }

    private val voskListener = object : VoskListener {
        override fun onPartialResult(hypothesis: String?) { voskCheck(hypothesis, "partial", false) }
        override fun onResult(hypothesis: String?) { voskCheck(hypothesis, "text", true) }
        override fun onFinalResult(hypothesis: String?) { voskCheck(hypothesis, "text", true) }
        override fun onError(exception: Exception?) { if (wakeOn) wakeFail("Vosk hatası: ${exception?.message}") }
        override fun onTimeout() {}
    }

    private fun stopWake() {
        wakeOn = false
        wakeGen++
        val svc = voskService
        val rec = voskRec
        voskService = null; voskRec = null
        try { svc?.stop() } catch (e: Throwable) {}
        try { svc?.shutdown() } catch (e: Throwable) {}
        try { rec?.close() } catch (e: Throwable) {}
    }

    private fun onWake() {
        runId++
        stopSpeech()
        showOrb()
        startListening()
    }

    // ---------- Küre ve pencere ----------
    private val hideRunnable = Runnable { if (!busy && panel == null && !always()) hideOrb() }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (!always()) handler.postDelayed(hideRunnable, 25000)
    }

    private fun showOrb() {
        handler.removeCallbacks(hideRunnable)
        if (orb != null) return
        if (!Settings.canDrawOverlays(this)) { toast("'Diğer uygulamaların üstünde göster' izni gerekli"); return }
        val v = OrbView(this)
        val size = dp(80)
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = dp(6); lp.y = dp(36)
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var drag = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) drag = true
                    if (drag) {
                        lp.x = (startX - dx).toInt().coerceAtLeast(0)
                        lp.y = (startY + dy).toInt().coerceAtLeast(0)
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!drag) { if (panel == null) showPanel() else closePanel() }
            }
            true
        }
        try { wm.addView(v, lp); orb = v; orbLp = lp } catch (e: Exception) { toast("Küre gösterilemedi: ${e.message}") }
    }

    private fun hideOrb() {
        closePanel(false)
        orb?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        orb = null
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; minWidth = 0; minimumWidth = 0; textSize = 13f
        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#33FFFFFF"))
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        if (panel != null) return
        showOrb()
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(10), dp(8), dp(10), dp(8))
        p.background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2101018")); cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#8A3DFF"))
        }
        p.addView(TextView(this).apply { text = "FAUSTO"; textSize = 12f; setTextColor(Color.parseColor("#B07CFF")) })
        val sv = ScrollView(this)
        val lv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = logBuf.toString() }
        sv.addView(lv)
        p.addView(sv, LinearLayout.LayoutParams(MATCH, dp(120)))

        val et = EditText(this).apply {
            hint = "Yaz..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 13f
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEND
        }
        fun doSend() {
            val t = et.text.toString().trim()
            if (t.isNotEmpty()) {
                et.setText("")
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
                setPanelFocusable(false)
                handleUser(t, false)
            }
        }
        et.setOnEditorActionListener { _, _, _ -> doSend(); true }
        et.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) {
                setPanelFocusable(true)
                handler.postDelayed({
                    et.requestFocus()
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 120)
            }
            false
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(et, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(smallBtn("Gönder") { doSend() })
        p.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(smallBtn("🎤 Konuş") { setPanelFocusable(false); runId++; stopSpeech(); onMicTap() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(smallBtn("⏹ Dur") { stopAll() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(smallBtn("✕") { closePanel() }, LinearLayout.LayoutParams(WRAP, WRAP))
        p.addView(row2, LinearLayout.LayoutParams(MATCH, WRAP))

        val lp = WindowManager.LayoutParams(
            dp(290), WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (orbLp?.x ?: 0) + dp(76)
        lp.y = orbLp?.y ?: dp(36)
        try {
            wm.addView(p, lp)
            panel = p; panelLp = lp; logView = lv; scroll = sv; edit = et
            sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        } catch (e: Exception) { toast("Pencere açılamadı: ${e.message}") }
    }

    private fun onMicTap() { startListening() }

    private fun setPanelFocusable(f: Boolean) {
        val lp = panelLp ?: return
        val p = panel ?: return
        lp.flags = if (f) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(p, lp) } catch (e: Exception) {}
    }

    private fun closePanel(schedule: Boolean = true) {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        panel = null; logView = null; scroll = null; edit = null
        if (schedule) scheduleHide()
    }

    private fun appendLog(t: String) {
        logBuf.append(if (logBuf.isEmpty()) "" else "\n").append(t)
        if (logBuf.length > 4000) logBuf.delete(0, logBuf.length - 3000)
        logView?.text = logBuf.toString()
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- Ses ----------
    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { orb?.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { appendLog("(Seni duyamadım)"); finish() }
        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) finish() else handleUser(t, true)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun startListening() {
        busy = true
        handler.removeCallbacks(hideRunnable)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            appendLog("Bu telefonda ses tanıma yok, yazarak konuş.")
            showPanel(); finish(); return
        }
        stopWake()
        orb?.setActive(true)
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            recognizer = r
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName))
        } catch (e: Exception) {
            appendLog("Mikrofon hatası: ${e.message}"); finish()
        }
    }

    private val pulseRun = object : Runnable {
        override fun run() {
            if (!pulsing) return
            orb?.level = 0.25f + rnd.nextFloat() * 0.75f
            handler.postDelayed(this, 110)
        }
    }

    private fun startPulse() { pulsing = true; orb?.setActive(true); handler.post(pulseRun) }

    private fun finish() {
        busy = false; pulsing = false
        orb?.level = 0f
        orb?.setActive(false)
        startWake()
        scheduleHide()
    }

    private fun stopAll() {
        runId++
        stopSpeech()
        try { recognizer?.cancel() } catch (e: Exception) {}
        appendLog("(Durduruldu)")
        finish()
    }

    private fun stopSpeech() {
        uttId++
        pulsing = false
        tts?.stop()
        try { player?.release() } catch (e: Exception) {}
        player = null
    }

    private fun speak(text: String) {
        val clean = text.replace(Regex("[*#`_>]"), "").take(500)
        if (clean.isBlank()) { finish(); return }
        stopWake()
        val id = ++uttId
        Thread {
            val f = try { cloud.synth(clean) } catch (e: Exception) { null }
            handler.post {
                if (id != uttId) return@post
                if (f != null) playFile(f, id, clean) else speakLocal(clean, id)
            }
        }.start()
    }

    private fun playFile(f: File, id: Int, clean: String) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { if (id == uttId) { it.start(); startPulse() } }
            mp.setOnCompletionListener { if (id == uttId) { try { it.release() } catch (e: Exception) {}; player = null; finish() } }
            mp.setOnErrorListener { _, _, _ -> if (id == uttId) { player = null; finish() }; true }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            speakLocal(clean, id)
        }
    }

    private fun speakLocal(clean: String, id: Int) {
        if (!ttsReady) { finish(); return }
        val r = tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "u$id")
        if (r != TextToSpeech.SUCCESS) finish()
    }

    private fun handleUser(text: String, voice: Boolean) {
        if (!voice) { stopSpeech(); try { recognizer?.cancel() } catch (e: Exception) {} }
        appendLog("Sen: $text")
        busy = true
        val myId = ++runId
        orb?.setActive(true)
        orb?.level = 0.25f
        startWake()
        Thread {
            val reply = try {
                brain.ask(text, { myId != runId }) { s -> handler.post { if (myId == runId) appendLog(s) } }
            } catch (e: Exception) { "Hata: ${e.message}" }
            handler.post {
                if (myId != runId) return@post
                appendLog("Fausto: $reply")
                if (voice) speak(reply) else finish()
            }
        }.start()
    }

    // ---------- Araçlar (Claude'un kullandıkları) ----------
    private fun gesture(f: (FaustoAccess, (Boolean) -> Unit) -> Unit): Boolean {
        val acc = FaustoAccess.instance ?: return false
        val latch = CountDownLatch(1)
        var ok = false
        f(acc) { ok = it; latch.countDown() }
        latch.await(5, TimeUnit.SECONDS)
        Thread.sleep(350)
        return ok
    }

    private fun look(): ToolResult {
        val acc = FaustoAccess.instance
            ?: return ToolResult("Erişilebilirlik servisi kapalı. Telefon Ayarları > Erişilebilirlik > Fausto'yu açmalı.")
        handler.post { orb?.visibility = View.INVISIBLE; panel?.visibility = View.INVISIBLE }
        Thread.sleep(300)
        var bmp: Bitmap? = null
        for (attempt in 0 until 2) {
            val latch = CountDownLatch(1)
            acc.screenshot { bmp = it; latch.countDown() }
            latch.await(6, TimeUnit.SECONDS)
            if (bmp != null) break
            Thread.sleep(1200)
        }
        handler.post { orb?.visibility = View.VISIBLE; panel?.visibility = View.VISIBLE }
        val b = bmp ?: return ToolResult("Ekran görüntüsü alınamadı. Android 11+ gerekir; kısa süre sonra tekrar denenebilir.")
        val scale = maxOf(1f, maxOf(b.width, b.height) / 1024f)
        val w = (b.width / scale).toInt()
        val h = (b.height / scale).toInt()
        val sb = Bitmap.createScaledBitmap(b, w, h, true)
        lastScale = scale
        val out = ByteArrayOutputStream()
        sb.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return ToolResult("Ekran görüntüsü ${w}x${h} piksel. Dokunma koordinatları bu görüntüye göre verilmeli.",
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
    }

    private fun saveFile(name: String, content: String): String {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "fausto.txt" }
        val ext = safe.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Fausto")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return "Dosya kaydedilemedi."
        contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
        return "Kaydedildi: Dosyalar > İndirilenler > Fausto > $safe"
    }

    private fun openApp(name: String): String {
        val tr = Locale.forLanguageTag("tr-TR")
        val q = name.lowercase(tr)
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = packageManager.queryIntentActivities(i, 0).firstOrNull { it.loadLabel(packageManager).toString().lowercase(tr).contains(q) }
            ?: return "'$name' adlı uygulama bulunamadı."
        val li = packageManager.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "Uygulama açılamadı."
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        handler.post { startActivity(li) }
        return "${m.loadLabel(packageManager)} açıldı."
    }

    override fun runTool(name: String, input: JSONObject): ToolResult {
        return try {
            when (name) {
                "look_at_screen" -> look()
                "tap" -> {
                    val x = input.getDouble("x").toFloat() * lastScale
                    val y = input.getDouble("y").toFloat() * lastScale
                    val ms = input.optLong("duration_ms", 60).coerceIn(20, 3000)
                    val ok = gesture { a, cb -> a.tap(x, y, ms, cb) }
                    ToolResult(if (ok) "Dokunuldu." else "Dokunma başarısız (erişilebilirlik kapalı olabilir).")
                }
                "swipe" -> {
                    val x1 = input.getDouble("x1").toFloat() * lastScale
                    val y1 = input.getDouble("y1").toFloat() * lastScale
                    val x2 = input.getDouble("x2").toFloat() * lastScale
                    val y2 = input.getDouble("y2").toFloat() * lastScale
                    val ms = input.optLong("duration_ms", 300).coerceIn(50, 3000)
                    val ok = gesture { a, cb -> a.swipe(x1, y1, x2, y2, ms, cb) }
                    ToolResult(if (ok) "Kaydırıldı." else "Kaydırma başarısız (erişilebilirlik kapalı olabilir).")
                }
                "press_key" -> {
                    val acc = FaustoAccess.instance ?: return ToolResult("Erişilebilirlik kapalı.")
                    val act = when (input.optString("key")) {
                        "back" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                        "home" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                        else -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
                    }
                    acc.performGlobalAction(act)
                    Thread.sleep(400)
                    ToolResult("Tuşa basıldı.")
                }
                "open_app" -> ToolResult(openApp(input.getString("name")))
                "create_file" -> ToolResult(saveFile(input.getString("filename"), input.getString("content")))
                "set_alarm" -> {
                    val it = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, input.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, input.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, input.optString("label", "Fausto"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    handler.post { startActivity(it) }
                    ToolResult("Alarm kuruldu.")
                }
                "remember" -> {
                    val old = prefs.getString("memory", "").orEmpty()
                    prefs.edit().putString("memory", (old + "\n- " + input.getString("note")).takeLast(3000)).apply()
                    ToolResult("Hatırlayacağım.")
                }
                else -> ToolResult("Bilinmeyen araç: $name")
            }
        } catch (e: Exception) {
            ToolResult("Hata: ${e.message}")
        }
    }
}
