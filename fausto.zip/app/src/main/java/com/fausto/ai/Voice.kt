package com.fausto.ai

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

class CloudVoice(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("fausto", Context.MODE_PRIVATE)
    private val models = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts", "gemini-2.5-flash-tts")
    @Volatile private var idx = 0
    @Volatile private var offUntil = 0L

    // Başarılıysa WAV dosyası döner, olmazsa null (telefonun kendi sesine düşülür)
    fun synth(text: String): File? {
        val key = prefs.getString("gemini_key", "").orEmpty().trim()
        if (key.isEmpty() || System.currentTimeMillis() < offUntil) return null
        val voice = prefs.getString("voice", "").orEmpty().trim().ifEmpty { "Charon" }
        var i = idx
        while (i < models.size) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))))
                    .put("generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${models[i]}:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 45000
                c.setRequestProperty("x-goog-api-key", key)
                c.setRequestProperty("content-type", "application/json")
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code == 200) {
                    val b64 = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                        .getJSONObject("inlineData").getString("data")
                    var bytes = Base64.decode(b64, Base64.DEFAULT)
                    if (!(bytes.size > 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF")) bytes = wav(bytes)
                    val f = File(ctx.cacheDir, "fausto_voice.wav")
                    f.writeBytes(bytes)
                    idx = i
                    return f
                }
                if (code == 404 || code == 400) { i++; continue }
                break
            } catch (e: Exception) {
                break
            }
        }
        offUntil = System.currentTimeMillis() + 120000
        return null
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val rate = 24000
        val ch = 1
        val bits = 16
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(ch.toShort())
        bb.putInt(rate); bb.putInt(rate * ch * bits / 8); bb.putShort((ch * bits / 8).toShort()); bb.putShort(bits.toShort())
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }
}
