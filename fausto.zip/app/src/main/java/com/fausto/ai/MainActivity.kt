package com.fausto.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var wakeEt: EditText
    private lateinit var wakeCb: CheckBox
    private lateinit var voiceEt: EditText
    private lateinit var alwaysCb: CheckBox
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: String) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color))
    }

    private fun field(hint: String, value: String, secret: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine()
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fausto", MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(28), dp(20), dp(28))
        fun add(v: View, top: Int = 10) {
            root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) })
        }

        add(label("FAUSTO", 28f, "#B07CFF"), 0)
        keyEt = field("Gemini API anahtarı (AIza...)", prefs.getString("gemini_key", "").orEmpty(), true)
        modelEt = field("Model (boş bırak, otomatik seçilir)", prefs.getString("model", "").orEmpty(), false)
        wakeEt = field("Uyandırma kelimeleri (virgülle ayır)", prefs.getString("wake_words", "").orEmpty().ifBlank { "fausto,faust,fosto,avusto,agustos" }, false)
        wakeCb = CheckBox(this).apply {
            text = "'Hey Fausto' diye dinle (Vosk, pil harcar)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("wake_on", false)
        }
        alwaysCb = CheckBox(this).apply {
            text = "Küre her zaman görünsün"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("always", false)
        }
        voiceEt = field("Erkek ses adı (boş: Charon; Orus, Algenib, Fenrir da denenebilir)", prefs.getString("voice", "").orEmpty(), false)
        add(keyEt, 20); add(modelEt); add(voiceEt); add(wakeCb); add(wakeEt)
        add(btn("Vosk Türkçe modeli (zip) seç") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 8)
        })
        add(label("Model: vosk-model-small-tr-0.3.zip (alphacephei.com/vosk/models adresinden indir, 35 MB)", 12f, "#999999"), 4)
        add(alwaysCb)
        add(label("İzinler", 16f, "#FF4466"), 18)
        add(btn("1) Diğer uygulamaların üstünde göster") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(btn("2) Erişilebilirlik > Fausto'yu aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        add(btn("3) Pil optimizasyonunu kapat") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        add(btn("BAŞLAT") { start() }, 18)
        add(btn("DURDUR") { stopService(Intent(this, FaustoService::class.java)); toast("Fausto durdu") })
        status = label("", 13f, "#CCCCCC")
        add(status, 18)

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0B12")); addView(root) })
    }

    override fun onResume() {
        super.onResume()
        fun t(b: Boolean) = if (b) "✓" else "✗"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Üstte gösterme: ${t(Settings.canDrawOverlays(this))}\n" +
            "Erişilebilirlik: ${t(FaustoAccess.instance != null)}\n" +
            "Mikrofon: ${t(mic)}\n" +
            "Vosk modeli: ${t(File(filesDir, "vosk-model/am").exists())}\n" +
            "Son duyulan (uyandırma): ${prefs.getString("last_heard", "-")}"
    }

    private fun save() {
        prefs.edit()
            .putString("gemini_key", keyEt.text.toString().trim())
            .putString("model", modelEt.text.toString().trim())
            .putString("wake_words", wakeEt.text.toString().trim())
            .putBoolean("wake_on", wakeCb.isChecked)
            .putString("voice", voiceEt.text.toString().trim())
            .putBoolean("always", alwaysCb.isChecked)
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun start() {
        save()
        if (!Settings.canDrawOverlays(this)) { toast("Önce 1) numaralı izni ver"); return }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        startForegroundService(Intent(this, FaustoService::class.java))
        toast(if (wakeCb.isChecked) "Fausto çalışıyor. 'Hey Fausto' de!" else "Fausto çalışıyor. Küreye dokun veya bildirimdeki Çağır'a bas.")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
        else toast("Mikrofon izni gerekli")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 8 && resultCode == RESULT_OK) installModel(data?.data ?: return)
    }

    private fun installModel(uri: Uri) {
        toast("Model açılıyor, birkaç saniye bekle...")
        Thread {
            try {
                val tmp = File(filesDir, "vosk-model-tmp")
                val dest = File(filesDir, "vosk-model")
                tmp.deleteRecursively(); tmp.mkdirs()
                val base = tmp.canonicalPath + File.separator
                var files = 0
                val tops = LinkedHashSet<String>()
                contentResolver.openInputStream(uri)?.use { ins ->
                    ZipInputStream(ins.buffered()).use { zin ->
                        var e = zin.nextEntry
                        while (e != null) {
                            tops.add(e.name.substringBefore('/'))
                            if (!e.isDirectory) {
                                files++
                                val out = File(tmp, e.name)
                                if (!out.canonicalPath.startsWith(base)) throw Exception("Geçersiz zip")
                                out.parentFile?.mkdirs()
                                out.outputStream().use { zin.copyTo(it) }
                            }
                            zin.closeEntry()
                            e = zin.nextEntry
                        }
                    }
                }
                val root = tmp.walkTopDown().maxDepth(5).firstOrNull { it.isDirectory && File(it, "am").isDirectory }
                    ?: throw Exception(
                        if (files == 0) "Seçtiğin dosya zip değil ya da boş"
                        else "Zip'te 'am' klasörü yok ($files dosya; içinde: ${tops.take(4).joinToString()})")
                dest.deleteRecursively()
                if (!root.renameTo(dest)) throw Exception("Model taşınamadı")
                tmp.deleteRecursively()
                runOnUiThread { toast("Vosk modeli yüklendi"); onResume() }
            } catch (e: Exception) {
                runOnUiThread { toast("Model yüklenemedi: ${e.message}") }
            }
        }.start()
    }
}
