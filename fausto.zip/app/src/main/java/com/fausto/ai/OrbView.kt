package com.fausto.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

class OrbView(ctx: Context) : View(ctx) {
    var level = 0f
    private var active = false
    private var running = false
    private var phase = 0f
    private val d = ctx.resources.displayMetrics.density
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.argb(200, 150, 60, 255)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }

    private val tick = object : Runnable {
        override fun run() {
            if (!active) { running = false; return }
            phase += 0.018f
            invalidate()
            postOnAnimation(this)
        }
    }

    fun setActive(a: Boolean) {
        active = a
        if (a && !running) { running = true; postOnAnimation(tick) }
        invalidate()
    }

    override fun onDetachedFromWindow() {
        active = false; running = false; removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width * 0.22f
        val maxR = width * 0.5f
        val gr = r * (1.5f + 0.6f * level)
        glow.shader = RadialGradient(
            cx, cy, gr,
            intArrayOf(Color.argb(170, 150, 40, 255), Color.argb(110, 255, 30, 70), Color.TRANSPARENT),
            floatArrayOf(0.45f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, gr, glow)
        if (active) {
            for (i in 0 until 3) {
                val t = (phase + i / 3f) % 1f
                val rr = r + t * (maxR - r) * (0.55f + 0.45f * level)
                val a = (200 * (1 - t)).toInt()
                ring.color = if (i % 2 == 0) Color.argb(a, 170, 60, 255) else Color.argb(a, 255, 40, 70)
                c.drawCircle(cx, cy, rr, ring)
            }
        }
        c.drawCircle(cx, cy, r, core)
        c.drawCircle(cx, cy, r, rim)
    }
}
